package com.cheatclient.mixin;

import com.cheatclient.CheatClientMod;
import com.cheatclient.config.CheatConfig;
import net.minecraft.class_1294;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
    
    @Inject(method = "tickMovement", at = @At("HEAD"), cancellable = true)
    private void onTickMovement(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_FLY)) {
            // Fly hack: Override gravity and allow controlled flight
            player.method_5875(true);
            
            // Apply upward velocity when jump key is pressed
            if (player.field_3913.field_3904) {
                player.method_5762(0, CheatConfig.FLY_SPEED, 0);
            }
            // Apply downward velocity when sneak key is pressed
            if (player.field_3913.field_3903) {
                player.method_5762(0, -CheatConfig.FLY_SPEED, 0);
            }
        } else {
            player.method_5875(false);
        }
        
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_SPEED)) {
            // Speed hack: Multiply movement speed
            float speedMultiplier = (float) CheatConfig.SPEED_MULTIPLIER;
            
            // Apply speed boost to movement attributes
            if (player.method_6059(class_1294.field_5904)) {
                player.method_5996(net.minecraft.class_5134.field_23719)
                    .method_6192(0.1f * speedMultiplier * 2.0f);
            } else {
                player.method_5996(net.minecraft.class_5134.field_23719)
                    .method_6192(0.1f * speedMultiplier);
            }
        }
    }
    
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void onSendMovementPackets(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_SPEED)) {
            // Speed hack: Augment movement delta in packets
            // TEMP_VALUE: This multiplier may need adjustment based on server validation
            double deltaMultiplier = CheatConfig.TEMP_PACKET_DELTA_MULTIPLIER;
            
            // The actual packet modification happens in the packet sending logic
            // This is a placeholder for where packet interception would occur
            // In a full implementation, you would hook into PlayerMoveC2SPacket
        }
    }
    
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onDamage(net.minecraft.class_1282 source, float amount, org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> cir) {
        class_746 player = (class_746) (Object) this;
        
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_NO_FALL)) {
            // Check if damage is from falling by checking the damage source name
            if (source.method_5525().equals("fall") || source.method_5525().equals("fall_damage")) {
                cir.setReturnValue(false); // Cancel fall damage
            }
        }
    }
}
