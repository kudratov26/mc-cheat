package com.cheatclient.mixin;

import com.cheatclient.CheatClientMod;
import com.cheatclient.config.CheatConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.minecraft.class_746;

@Mixin(class_746.class)
public class PlayerTickMixin {
    
    private long lastAttackTime = 0;
    private long lastClickTime = 0;
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void onPlayerTick(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        
        if (player.method_37908() == null || !player.method_5805()) return;
        
        // Kill Aura implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_KILL_AURA)) {
            performKillAura(player);
        }
        
        // Trigger Bot implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_TRIGGER_BOT)) {
            performTriggerBot(player);
        }
        
        // Auto Clicker implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_CLICKER)) {
            performAutoClicker(player);
        }
        
        // Auto Soup implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_SOUP)) {
            performAutoSoup(player);
        }
    }
    
    private void performKillAura(class_746 player) {
        // Find nearest hostile entity within range
        List<class_1297> nearbyEntities = player.method_37908().method_8335(player, player.method_5829().method_1014(CheatConfig.KILL_AURA_RANGE));
        
        class_1309 target = null;
        double closestDistance = Double.MAX_VALUE;
        
        for (class_1297 entity : nearbyEntities) {
            if (entity instanceof class_1309 && ((class_1309) entity).method_5805()) {
                double distance = player.method_5858(entity);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    target = (class_1309) entity;
                }
            }
        }
        
        if (target != null) {
            // Auto-attack target without aim assist - just hit regardless of crosshair
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAttackTime > (CheatConfig.TEMP_ATTACK_DELAY_TICKS * 50)) {
                player.method_7324(target);
                lastAttackTime = currentTime;
            }
        }
    }
    
    private void performTriggerBot(class_746 player) {
        // Check if player is looking at an entity
        class_239 hitResult = player.method_5745(CheatConfig.TRIGGER_BOT_RANGE, 0, false);
        
        if (hitResult.method_17783() == class_239.class_240.field_1331) {
            class_3966 entityHit = (class_3966) hitResult;
            class_1297 target = entityHit.method_17782();
            
            if (target instanceof class_1309 && ((class_1309) target).method_5805()) {
                // Auto-attack without aim assist - just hit when crosshair is on target
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastAttackTime > (CheatConfig.TEMP_ATTACK_DELAY_TICKS * 50)) {
                    player.method_7324((class_1309) target);
                    lastAttackTime = currentTime;
                }
            }
        }
    }
    
    private void performAutoClicker(class_746 player) {
        long currentTime = System.currentTimeMillis();
        long clickInterval = 1000 / CheatConfig.AUTO_CLICKER_CPS;
        
        // TEMP_VALUE: Add randomization to avoid detection
        if (CheatConfig.TEMP_RANDOMIZE_TIMING) {
            clickInterval += (long) (Math.random() * 50 - 25);
        }
        
        if (currentTime - lastClickTime >= clickInterval) {
            // Simulate left click
            if (player.method_7261(0) >= 1.0f) {
                // This would hook into the mouse click event
                // For now, this is a placeholder for where click injection would occur
                lastClickTime = currentTime;
            }
        }
    }
    
    private void performAutoSoup(class_746 player) {
        // Check if health is below threshold (4 hearts)
        if (player.method_6032() <= CheatConfig.AUTO_SOUP_HEALTH_THRESHOLD) {
            // Find mushroom soup in hotbar
            int soupSlot = -1;
            for (int i = 0; i < 9; i++) {
                if (player.method_31548().method_5438(i).method_7909() == class_1802.field_8208) {
                    soupSlot = i;
                    break;
                }
            }
            
            if (soupSlot != -1) {
                // Switch to soup slot
                player.method_31548().field_7545 = soupSlot;
                
                // Auto-eat soup (this would hook into right-click event)
                // For now, this is a placeholder for where item usage would be injected
                if (player.method_6047().method_7909() == class_1802.field_8208) {
                    // Force eat soup
                    // This would typically be done through item usage mixin
                    // After eating, the bowl would be in hand - need to drop it
                }
            } else {
                // No soup in hotbar, try to find in inventory and move to hotbar
                int inventorySoupSlot = -1;
                for (int i = 9; i < 36; i++) {
                    if (player.method_31548().method_5438(i).method_7909() == class_1802.field_8208) {
                        inventorySoupSlot = i;
                        break;
                    }
                }
                
                if (inventorySoupSlot != -1) {
                    // Find empty hotbar slot
                    int emptyHotbarSlot = -1;
                    for (int i = 0; i < 9; i++) {
                        if (player.method_31548().method_5438(i).method_7960()) {
                            emptyHotbarSlot = i;
                            break;
                        }
                    }
                    
                    if (emptyHotbarSlot != -1) {
                        // Move soup from inventory to hotbar
                        player.method_31548().field_7547.set(inventorySoupSlot, player.method_31548().field_7547.get(emptyHotbarSlot));
                        player.method_31548().field_7547.set(emptyHotbarSlot, new net.minecraft.class_1799(class_1802.field_8208));
                    }
                }
            }
        }
    }
}
