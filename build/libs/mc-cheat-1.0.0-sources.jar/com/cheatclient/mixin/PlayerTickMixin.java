package com.cheatclient.mixin;

import com.cheatclient.CheatClientMod;
import com.cheatclient.CheatMenuHandler;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;

@Mixin(class_746.class)
public class PlayerTickMixin {
    
    private long lastAttackTime = 0;
    private long lastClickTime = 0;
    private static final double KILL_AURA_RANGE = 4.0;
    private static final double TRIGGER_BOT_RANGE = 3.5;
    private static final int AUTO_CLICKER_CPS = 15;
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void onPlayerTick(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        
        if (player.method_37908() == null || !player.method_5805()) return;
        
        // Check for Right Shift key press to open menu
        class_310 client = class_310.method_1551();
        long window = client.method_22683().method_4490();
        
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS) {
            if (!menuOpen) {
                menuOpen = true;
                if (client.field_1724 != null) {
                    client.method_1507(new CheatMenuHandler(client));
                }
            }
        } else {
            menuOpen = false;
        }
        
        // Kill Aura implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_KILL_AURA)) {
            performKillAura(player);
        }
        
        // Trigger Bot implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_TRIGGER_BOT)) {
            performTriggerBot(player);
        }
        
        // Auto Clicker implementation
        if (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_CLICKER)) {
            performAutoClicker(player);
        }
    }
    
    private void performKillAura(class_746 player) {
        // Find nearest hostile entity within range
        List<class_1297> nearbyEntities = player.method_37908().method_8335(player, player.method_5829().method_1014(KILL_AURA_RANGE));
        
        class_1309 target = null;
        double closestDistance = Double.MAX_VALUE;
        
        for (class_1297 entity : nearbyEntities) {
            if (entity instanceof class_1309 && ((class_1309) entity).method_5805()) {
                double distance = player.method_5858(entity);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    target = (class_1309) entity;
                }
            }
        }
        
        if (target != null) {
            // Auto-attack target without aim assist - just hit regardless of crosshair
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAttackTime > 100) {
                player.method_7324(target);
                lastAttackTime = currentTime;
            }
        }
    }
    
    private void performTriggerBot(class_746 player) {
        // Check if player is looking at an entity
        class_239 hitResult = player.method_5745(TRIGGER_BOT_RANGE, 0, false);
        
        if (hitResult.method_17783() == class_239.class_240.field_1331) {
            class_3966 entityHit = (class_3966) hitResult;
            class_1297 target = entityHit.method_17782();
            
            if (target instanceof class_1309 && ((class_1309) target).method_5805()) {
                // Auto-attack without aim assist - just hit when crosshair is on target
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastAttackTime > 100) {
                    player.method_7324((class_1309) target);
                    lastAttackTime = currentTime;
                }
            }
        }
    }
    
    private void performAutoClicker(class_746 player) {
        long currentTime = System.currentTimeMillis();
        long clickInterval = 1000 / AUTO_CLICKER_CPS;
        
        if (currentTime - lastClickTime >= clickInterval) {
            // Simulate left click
            if (player.method_7261(0) >= 1.0f) {
                // This would hook into the mouse click event
                // For now, this is a placeholder for where click injection would occur
                lastClickTime = currentTime;
            }
        }
    }
    
    private static boolean menuOpen = false;
}
