package com.cheatclient;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CheatMenuHandler extends class_437 {
    private final class_310 client;
    private float animationProgress = 0f;
    private float targetAnimation = 1f;
    
    public CheatMenuHandler(class_310 client) {
        super(class_2561.method_30163("Omni-Injector Cheat Menu"));
        this.field_22787 = client;
    }
    
    @Override
    protected void method_25426() {
        int buttonWidth = 220;
        int buttonHeight = 24;
        int startY = 60;
        int spacing = 30;
        
        // Auto Clicker
        this.method_37063(createStyledButton(
            "Auto Clicker", CheatClientMod.FEATURE_AUTO_CLICKER,
            this.field_22789 / 2 - buttonWidth / 2, startY, buttonWidth, buttonHeight
        ));
        
        // Kill Aura
        this.method_37063(createStyledButton(
            "Kill Aura", CheatClientMod.FEATURE_KILL_AURA,
            this.field_22789 / 2 - buttonWidth / 2, startY + spacing, buttonWidth, buttonHeight
        ));
        
        // Trigger Bot
        this.method_37063(createStyledButton(
            "Trigger Bot", CheatClientMod.FEATURE_TRIGGER_BOT,
            this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 2, buttonWidth, buttonHeight
        ));
        
        // Fly
        this.method_37063(createStyledButton(
            "Fly", CheatClientMod.FEATURE_FLY,
            this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 3, buttonWidth, buttonHeight
        ));
        
        // Speed
        this.method_37063(createStyledButton(
            "Speed", CheatClientMod.FEATURE_SPEED,
            this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 4, buttonWidth, buttonHeight
        ));
        
        // No Fall Damage
        this.method_37063(createStyledButton(
            "No Fall", CheatClientMod.FEATURE_NO_FALL,
            this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 5, buttonWidth, buttonHeight
        ));
        
        // Auto Soup
        this.method_37063(createStyledButton(
            "Auto Soup", CheatClientMod.FEATURE_AUTO_SOUP,
            this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 6, buttonWidth, buttonHeight
        ));
        
        // Close button
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("§cClose"),
            button -> {
                targetAnimation = 0f;
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 8, buttonWidth, buttonHeight).method_46431());
    }
    
    private class_4185 createStyledButton(String name, String featureName, int x, int y, int width, int height) {
        boolean isActive = CheatClientMod.getInstance().isFeatureActive(featureName);
        String status = isActive ? "§a§lON" : "§c§lOFF";
        String buttonText = "§7" + name + " §8| " + status;
        
        return class_4185.method_46430(
            class_2561.method_30163(buttonText),
            button -> {
                CheatClientMod.getInstance().toggleFeature(featureName);
                boolean newState = CheatClientMod.getInstance().isFeatureActive(featureName);
                String newStatus = newState ? "§a§lON" : "§c§lOFF";
                button.method_25355(class_2561.method_30163("§7" + name + " §8| " + newStatus));
            }
        ).method_46434(x, y, width, height).method_46431();
    }
    
    @Override
    public void method_25394(net.minecraft.class_332 context, int mouseX, int mouseY, float delta) {
        // Update animation
        animationProgress += (targetAnimation - animationProgress) * 0.15f * delta;
        
        // Close menu when animation completes
        if (targetAnimation == 0f && animationProgress < 0.01f) {
            this.method_25419();
            return;
        }
        
        // Render animated background
        renderAnimatedBackground(context, delta);
        
        // Render title with animation
        float titleAlpha = Math.min(animationProgress * 1.5f, 1f);
        context.method_27534(this.field_22793, class_2561.method_30163("§c§lOmni-Injector"), this.field_22789 / 2, (int)(30 * animationProgress), 0xFFFFFF);
        
        // Render buttons with animation
        for (int i = 0; i < this.method_25396().size(); i++) {
            if (this.method_25396().get(i) instanceof class_4185 button) {
                float buttonAnimation = Math.max(0, Math.min((animationProgress - i * 0.1f) * 2f, 1f));
                if (buttonAnimation > 0) {
                    button.method_46419((int)(button.method_46427() * buttonAnimation));
                }
            }
        }
        
        super.method_25394(context, mouseX, mouseY, delta);
    }
    
    private void renderAnimatedBackground(net.minecraft.class_332 context, float delta) {
        int width = this.field_22789;
        int height = this.field_22790;
        float alpha = animationProgress * 0.85f;
        
        // Main background with gradient effect
        int bgColor = ((int)(alpha * 180) << 24) | 0x100010;
        context.method_25294(0, 0, width, height, bgColor);
        
        // Animated border
        int borderColor = ((int)(alpha * 255) << 24) | 0xFF3333;
        int borderThickness = 2;
        context.method_25294(0, 0, width, borderThickness, borderColor);
        context.method_25294(0, height - borderThickness, width, height, borderColor);
        context.method_25294(0, 0, borderThickness, height, borderColor);
        context.method_25294(width - borderThickness, 0, width, height, borderColor);
        
        // Animated corner accents
        int accentColor = ((int)(alpha * 255) << 24) | 0xFF5555;
        context.method_25294(0, 0, 50, 3, accentColor);
        context.method_25294(0, 0, 3, 50, accentColor);
        context.method_25294(width - 50, height - 3, width, height, accentColor);
        context.method_25294(width - 3, height - 50, width, height, accentColor);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
}
