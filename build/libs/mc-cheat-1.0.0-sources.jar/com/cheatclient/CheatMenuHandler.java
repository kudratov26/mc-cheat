package com.cheatclient;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CheatMenuHandler extends class_437 {
    private final class_310 client;
    
    public CheatMenuHandler(class_310 client) {
        super(class_2561.method_30163("Omni-Injector Cheat Menu"));
        this.field_22787 = client;
    }
    
    @Override
    protected void method_25426() {
        int buttonWidth = 200;
        int buttonHeight = 20;
        int startY = 50;
        int spacing = 25;
        
        // Auto Clicker
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Auto Clicker: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_CLICKER) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_AUTO_CLICKER);
                button.method_25355(class_2561.method_30163("Auto Clicker: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_CLICKER) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY, buttonWidth, buttonHeight).method_46431());
        
        // Kill Aura
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Kill Aura: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_KILL_AURA) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_KILL_AURA);
                button.method_25355(class_2561.method_30163("Kill Aura: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_KILL_AURA) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing, buttonWidth, buttonHeight).method_46431());
        
        // Trigger Bot
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Trigger Bot: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_TRIGGER_BOT) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_TRIGGER_BOT);
                button.method_25355(class_2561.method_30163("Trigger Bot: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_TRIGGER_BOT) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 2, buttonWidth, buttonHeight).method_46431());
        
        // Fly
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Fly: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_FLY) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_FLY);
                button.method_25355(class_2561.method_30163("Fly: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_FLY) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 3, buttonWidth, buttonHeight).method_46431());
        
        // Speed
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Speed: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_SPEED) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_SPEED);
                button.method_25355(class_2561.method_30163("Speed: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_SPEED) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 4, buttonWidth, buttonHeight).method_46431());
        
        // No Fall Damage
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("No Fall: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_NO_FALL) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_NO_FALL);
                button.method_25355(class_2561.method_30163("No Fall: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_NO_FALL) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 5, buttonWidth, buttonHeight).method_46431());
        
        // Auto Soup
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Auto Soup: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_SOUP) ? "ON" : "OFF")),
            button -> {
                CheatClientMod.getInstance().toggleFeature(CheatClientMod.FEATURE_AUTO_SOUP);
                button.method_25355(class_2561.method_30163("Auto Soup: " + (CheatClientMod.getInstance().isFeatureActive(CheatClientMod.FEATURE_AUTO_SOUP) ? "ON" : "OFF")));
            }
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 6, buttonWidth, buttonHeight).method_46431());
        
        // Close button
        this.method_37063(class_4185.method_46430(
            class_2561.method_30163("Close"),
            button -> this.method_25419()
        ).method_46434(this.field_22789 / 2 - buttonWidth / 2, startY + spacing * 8, buttonWidth, buttonHeight).method_46431());
    }
    
    @Override
    public void method_25394(net.minecraft.class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
}
